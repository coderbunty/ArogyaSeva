-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: arogyaseva
-- ------------------------------------------------------
-- Server version	5.5.41-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctor` (
  `doctorId` int(11) NOT NULL,
  `doctorName` varchar(20) NOT NULL,
  `hospital` varchar(40) DEFAULT NULL,
  `specialization` varchar(40) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`doctorId`),
  KEY `userId` (`userId`),
  CONSTRAINT `doctor_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctor`
--

LOCK TABLES `doctor` WRITE;
/*!40000 ALTER TABLE `doctor` DISABLE KEYS */;
INSERT INTO `doctor` VALUES (1,'Suraj','Vydehi','Heart Specialist','Bangalore',2),(2,'Vijaya','Cummins','ENT','Indore',3),(3,'Meghana','AIIMS','Neurologist','Bangalore',4);
/*!40000 ALTER TABLE `doctor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event` (
  `eventId` int(11) NOT NULL,
  `description` varchar(100) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `doctorId` int(11) NOT NULL,
  `eventDate` date NOT NULL,
  `state` varchar(20) NOT NULL,
  PRIMARY KEY (`eventId`),
  KEY `schoolId` (`schoolId`),
  KEY `doctorId` (`doctorId`),
  CONSTRAINT `event_ibfk_1` FOREIGN KEY (`schoolId`) REFERENCES `school` (`schoolId`),
  CONSTRAINT `event_ibfk_2` FOREIGN KEY (`doctorId`) REFERENCES `doctor` (`doctorId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES (1,'Annual Check up',2,1,'2015-04-25','INPROGRESS'),(2,'Annual Check up',3,2,'2015-04-24','INPROGRESS'),(3,'Annual Check up',1,1,'2015-04-26','INPROGRESS'),(4,'Annual Check up',4,2,'2015-04-28','INPROGRESS'),(5,'Annual Check up',6,1,'2015-04-29','FINISHED'),(6,'Annual Check up',7,2,'2015-04-30','INPROGRESS');
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eventmapping`
--

DROP TABLE IF EXISTS `eventmapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eventmapping` (
  `eventMappingId` int(11) NOT NULL,
  `eventId` int(11) NOT NULL,
  `volunteerId` int(11) NOT NULL,
  `taskState` varchar(1) NOT NULL,
  PRIMARY KEY (`eventMappingId`),
  KEY `volunteerId` (`volunteerId`),
  KEY `eventId` (`eventId`),
  CONSTRAINT `eventmapping_ibfk_1` FOREIGN KEY (`volunteerId`) REFERENCES `volunteer` (`volunteerId`),
  CONSTRAINT `eventmapping_ibfk_2` FOREIGN KEY (`eventId`) REFERENCES `event` (`eventId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eventmapping`
--

LOCK TABLES `eventmapping` WRITE;
/*!40000 ALTER TABLE `eventmapping` DISABLE KEYS */;
INSERT INTO `eventmapping` VALUES (1,1,5,'P'),(2,1,2,'P'),(3,2,3,'P'),(4,3,5,'P'),(5,4,5,'P'),(6,3,4,'P'),(7,2,5,'P'),(8,5,4,'P'),(9,6,5,'P');
/*!40000 ALTER TABLE `eventmapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medical_readings`
--

DROP TABLE IF EXISTS `medical_readings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medical_readings` (
  `readingId` int(11) NOT NULL,
  `studentId` int(11) NOT NULL,
  `timeStampNo` int(11) NOT NULL,
  `time_stamp` varchar(20) NOT NULL,
  `height` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  `chestNormal` int(11) NOT NULL,
  `chestExpand` int(11) NOT NULL,
  `photo` longblob,
  `remarks` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`readingId`),
  KEY `studentId` (`studentId`),
  CONSTRAINT `medical_readings_ibfk_1` FOREIGN KEY (`studentId`) REFERENCES `student` (`studentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medical_readings`
--

LOCK TABLES `medical_readings` WRITE;
/*!40000 ALTER TABLE `medical_readings` DISABLE KEYS */;
INSERT INTO `medical_readings` VALUES (1,1,1,'15-4-2014_23-34-56',25,25,34,45,NULL,NULL),(2,1,2,'16-4-2014_23-34-56',24,56,5,1,NULL,NULL),(3,2,1,'15-4-2014_23-34-56',57,77,2,2,NULL,NULL),(4,1,3,'17-4-2014_23-34-56',53,64,7,3,NULL,NULL),(5,3,1,'15-4-2014_23-34-56',75,58,4,4,NULL,NULL),(6,3,2,'15-4-2014_23-34-56',7,38,6,5,NULL,NULL),(7,4,1,'15-4-2014_23-34-56',23,36,5,6,NULL,NULL),(8,2,2,'15-4-2014_23-34-56',68,48,67,89,NULL,NULL),(9,6,1,'2015-04-22_11-15-09',90,25,20,22,NULL,NULL),(10,7,1,'2015-04-22_11-23-40',80,28,20,22,NULL,NULL),(11,8,1,'2015-04-22_12-19-02',108,30,26,28,NULL,NULL),(12,9,1,'2015-04-22_13-28-44',100,35,30,32,NULL,NULL),(13,10,1,'2015-04-22_13-36-36',160,56,35,37,NULL,NULL),(14,11,1,'2015-04-22_13-37-38',150,39,30,32,NULL,NULL),(15,12,1,'2015-04-22_14-16-49',120,30,28,30,NULL,NULL),(16,13,1,'2015-04-22_14-48-52',100,29,28,30,NULL,NULL),(17,14,1,'2015-04-22_16-47-15',150,50,35,38,NULL,NULL);
/*!40000 ALTER TABLE `medical_readings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `school`
--

DROP TABLE IF EXISTS `school`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `school` (
  `schoolId` int(11) NOT NULL,
  `schoolname` varchar(40) NOT NULL,
  `locationCoordinates` varchar(50) DEFAULT NULL,
  `village` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`schoolId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `school`
--

LOCK TABLES `school` WRITE;
/*!40000 ALTER TABLE `school` DISABLE KEYS */;
INSERT INTO `school` VALUES (1,'Vidya Bharathi','12.2958,76.6394','Shimoga','Karnataka'),(2,'Loyola School','12.2958,76.6394','Shimoga','Karnataka'),(3,'Noble School','12.2958,76.6394','Gulbarga','Karnataka'),(4,'Bal Bhavan','12.2958,76.6394','Gulbarga','Karnataka'),(5,'St Annes Lion\'s School','12.2958,76.6394','Bagalkot','Karnataka'),(6,'Guru Nanak School','12.2958,76.6394','Bidar','Karnataka'),(7,'Sacred Heart ','12.2958,76.6394','Shimoga','Karnataka'),(8,'DVS Composite','12.2958,76.6394','Shimoga','Karnataka'),(9,'Jnanadeepa School','12.2958,76.6394','Shimoga','Karnataka'),(10,'Delhi Public School','12.2958,76.6394','Delhi','Delhi');
/*!40000 ALTER TABLE `school` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `studentId` int(11) NOT NULL,
  `rollNo` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `age` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  PRIMARY KEY (`studentId`),
  KEY `schoolId` (`schoolId`),
  CONSTRAINT `student_ibfk_1` FOREIGN KEY (`schoolId`) REFERENCES `school` (`schoolId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (1,1,'Abhishek Bacchan',25,1),(2,2,'Abhijeet Singh',26,2),(3,3,'Akash Srivatsav',25,1),(4,4,'Avinash Kedlaya',26,2),(6,1,'Abhishek Sharma',8,3),(7,57,'Sai Nath',8,3),(8,45,'Rahul Singh',13,3),(9,68,'Supreeth Karnalli',10,3),(10,10,'Farhan Khan',15,2),(11,5,'Deepika Sharma',17,2),(12,5,'Annapoorna Sharma',10,3),(13,45,'Priyanka Sharma',10,3),(14,110,'Chirag Shah',25,1);
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `userId` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(20) NOT NULL,
  `userType` varchar(1) NOT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'jigar','jigar','V'),(2,'Suraj','suraj','D'),(3,'Vijaya','vijaya','D'),(4,'Meghana','meghana','D'),(5,'abhi','abhi','V'),(6,'Dhruv','dhruv','V'),(7,'Shivang','shivang','V'),(8,'Jitendra','jitendra','V'),(9,'Aditya','aditya','V');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volunteer`
--

DROP TABLE IF EXISTS `volunteer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volunteer` (
  `volunteerId` int(11) NOT NULL,
  `address` varchar(60) DEFAULT NULL,
  `organization` varchar(40) DEFAULT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`volunteerId`),
  KEY `userId` (`userId`),
  CONSTRAINT `volunteer_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volunteer`
--

LOCK TABLES `volunteer` WRITE;
/*!40000 ALTER TABLE `volunteer` DISABLE KEYS */;
INSERT INTO `volunteer` VALUES (1,'abcd','IIITB',1),(2,'efgh','IIN',8),(3,'ijkl','IIN',7),(4,'mnop','IIITB',6),(5,'qrst','IIN',5),(6,'uvwx','IIITB',9);
/*!40000 ALTER TABLE `volunteer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-22 17:12:28
