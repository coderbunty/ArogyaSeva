package com.arogyaseva.service.resources;

import java.util.ArrayList;
import java.util.Iterator;


import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.arogyaseva.service.dto.EventDetails;
import com.arogyaseva.service.dto.StudentInfo;
import com.arogyaseva.service.dto.UserDetails;
import com.sun.jersey.core.util.Base64;

public class Utility
{	
	public static String constructEventJSONObject(ArrayList<EventDetails> values)
	{
		JSONArray jArray = new JSONArray();
		JSONObject jObj;
		EventDetails eventDetails;
		Iterator<EventDetails> it = values.iterator();
		int cnt = 0;
		while(it.hasNext())
		{
			eventDetails = (EventDetails)it.next();
			try
			{
				jObj = new JSONObject();
				jObj.put("id", ++cnt);
				jObj.put("name", eventDetails.getSchool());
				jObj.put("eventId", eventDetails.getEventId());
				jObj.put("evDate", eventDetails.getDate());
				jObj.put("gps", eventDetails.getGpsCoordinates());
				jObj.put("taskState", eventDetails.getEventState());
				jArray.put(jObj);
			} catch (JSONException e)
			{
				e.printStackTrace();
			}
		}
		try
		{
			//return new JSONObject().put("feed", jArray).toString();
			return jArray.toString();
		} catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static String constructLoginJSONObject(UserDetails userDetails)
	{
		JSONObject jObj = null;
		try
		{
			jObj = new JSONObject();
			jObj.put("userId", userDetails.getUserId());
			jObj.put("userName", userDetails.getUserName());
			jObj.put("password", userDetails.getPassword());
			jObj.put("userType", userDetails.getUserType());
		} catch (JSONException e)
		{
			e.printStackTrace();
		}
		return jObj.toString();
	}
	
	public ArrayList<StudentInfo> getParsedStudentInfoList(String jsonString)
	{
		try
		{
			JSONArray ar = new JSONArray(jsonString);
			ArrayList<StudentInfo> studentInfoArrayList = new ArrayList<StudentInfo>();

			for (int i = 0; i < ar.length(); i++)
			{
				JSONObject obj = ar.getJSONObject(i);
				StudentInfo studentInfo = new StudentInfo();

				studentInfo.setStudentId(obj.getInt("id"));
				studentInfo.setfName(obj.getString("fName"));
				studentInfo.setlName(obj.getString("lName"));
				studentInfo.setRoll(obj.getInt("rollNo"));
				studentInfo.setAge(obj.getInt("age"));
				studentInfo.setHeight(obj.getInt("height"));
				studentInfo.setWeight(obj.getInt("weight"));
				studentInfo.setcNormal(obj.getInt("cNormal"));
				studentInfo.setcExpand(obj.getInt("cExpand"));
				studentInfo.setSchool(obj.getString("school"));
				studentInfo.setDateTime(obj.getString("dateTime"));
				studentInfo.setImage_str(obj.getString("image"));
				studentInfoArrayList.add(studentInfo);
			}

			return studentInfoArrayList;
		} catch (JSONException e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	
	
	public static String constructStudentInfoListJSONObject(ArrayList<StudentInfo> values)
	{
		JSONArray jArray = new JSONArray();
		JSONObject jObj;
		StudentInfo studentInfo;
		int cnt = 0;
		Iterator<StudentInfo> it = values.iterator();
		while(it.hasNext())
		{
			studentInfo = (StudentInfo)it.next();
			try
			{
				jObj = new JSONObject();
				jObj.put("id", cnt++);
				jObj.put("fName", studentInfo.getfName());
				jObj.put("lName", studentInfo.getlName());
				jObj.put("rollNo", studentInfo.getRoll());
				jObj.put("age", studentInfo.getAge());
				jObj.put("height", studentInfo.getHeight());
				jObj.put("weight", studentInfo.getWeight());
				jObj.put("cNormal", studentInfo.getcNormal());
				jObj.put("cExpand", studentInfo.getcExpand());
				jObj.put("school", studentInfo.getSchool());
				jObj.put("dateTime", studentInfo.getDateTime());
				jObj.put("image", studentInfo.getImage_str());
				jArray.put(jObj);
			} catch (JSONException e)
			{
				e.printStackTrace();
			}
		}
		try
		{
			//return new JSONObject().put("feed", jArray).toString();
			return jArray.toString();
		} catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static String constructResponseJSONObject(boolean flag)
	{
		JSONObject jObj = new JSONObject();
		try
		{
			if(flag)
			{
				jObj.put("result", "success");
				return jObj.toString();
			}
			else
			{
				jObj.put("result", "failure");
				return jObj.toString();
			}
		} catch (JSONException e)
		{
			e.printStackTrace();
			return null;
		}
	}
}
