package com.arogyaseva.service.resources;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import com.arogyaseva.service.Dao.LoginDao;
import com.arogyaseva.service.dto.UserDetails;

@Path("/login")
public class Login
{
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String eventsForPerticularVolunteer(@QueryParam("uName")String uName, @QueryParam("pass")String pass)
	{
		//http://localhost:8080/com.arogyaseva.service/api/login
		LoginDao loginDao = new LoginDao();
		String response = "";
		UserDetails userDetails = new UserDetails();
		userDetails = loginDao.getUserDetails(uName, pass);
		response = Utility.constructLoginJSONObject(userDetails);
		return response;
	}
}

