package com.arogyaseva.service.resources;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import com.arogyaseva.service.Dao.EventsDao;
import com.arogyaseva.service.Dao.EventsDaoImpl;
import com.arogyaseva.service.dto.EventDetails;

@Path("/events")
public class Events
{
	EventsDao eventDao = new EventsDaoImpl();
	
	@GET
	@Path("{volunteerParam}")
	@Produces(MediaType.APPLICATION_JSON)
	public String eventsForPerticularVolunteer(@PathParam("volunteerParam") int volunteerId)
	{
		//http://localhost:8080/com.arogyaseva.service/api/events/{param}
		String response = "";
		ArrayList<EventDetails> eventDetailsList = new ArrayList<EventDetails>();
		eventDetailsList = eventDao.getEventDetails(volunteerId);
		response = Utility.constructEventJSONObject(eventDetailsList);
		return response;
	}
	
	@PUT
	@Path("{volunteerParam}/{eventParam}")
	@Consumes("application/x-www-form-urlencoded")
	public void eventForParticularVolunteer(@PathParam("volunteerParam") int volunteerId, @PathParam("eventParam") int eventId, MultivaluedMap<String, String> mapParams)
	{
		//System.out.println(volunteerId + " " + eventId);
		if(mapParams.get("updType").get(0).equals("R"))
			eventDao.removeEventOnReject(volunteerId, eventId);
		else if(mapParams.get("updType").get(0).equals("A"))
			eventDao.updateEventOnAccept(volunteerId, eventId);
	}
}
