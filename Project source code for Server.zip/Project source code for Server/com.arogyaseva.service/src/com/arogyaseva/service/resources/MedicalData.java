package com.arogyaseva.service.resources;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import com.arogyaseva.service.Dao.StudentInfoDao;
import com.arogyaseva.service.dto.StudentInfo;

@Path("/medicalData")
public class MedicalData
{
	StudentInfoDao studentInfoDao = new StudentInfoDao();
	
	@POST
	@Path("/upload")
	@Consumes("application/x-www-form-urlencoded")
	@Produces(MediaType.APPLICATION_JSON)
	public String uploadStudentInfo(MultivaluedMap<String, String> mapParams)
	{
		ArrayList<StudentInfo> studentInfoList = null;
		String studentInfoListString = mapParams.get("Student Upload Data").get(0);
		studentInfoList = new Utility().getParsedStudentInfoList(studentInfoListString);
		boolean flag = studentInfoDao.saveStudentInfo(studentInfoList);
		return Utility.constructResponseJSONObject(flag);
	}
	
	@GET
	@Path("{eventName}")
	@Produces(MediaType.APPLICATION_JSON)
	public String downloadStudentInfo(@PathParam("eventName") String schoolName)
	{
		String response = null;
		schoolName = schoolName.replace("_", " ");
		ArrayList<StudentInfo> studentInfoList = studentInfoDao.getStudentInfo(schoolName);
		response = Utility.constructStudentInfoListJSONObject(studentInfoList);
		return response;
	}
}
