package com.arogyaseva.service.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

//import com.mysql.jdbc.PreparedStatement;

import com.arogyaseva.service.dto.EventDetails;

public class EventsDaoImpl implements EventsDao
{
	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost:3306/test";
	
	// Database credentials
	static final String USER = "root";
	static final String PASS = "jigar";

	/* (non-Javadoc)
	 * @see com.arogyaseva.service.Dao.EventsDao#getEventDetails(int)
	 */
	@Override
	public ArrayList<EventDetails> getEventDetails(int volunteerId)
	{
		ArrayList<EventDetails> eventDetailsList = new ArrayList<EventDetails>();
		EventDetails eventDetails;
		
		try
		{
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		Connection con = null;
		String sqlOuter = null;
		String sqlInner = null;
		PreparedStatement prepStmt = null;
		
		try
		{
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			sqlOuter = "select eventId, taskState from arogyaseva.eventmapping where volunteerId = ? and (taskState = 'P' or taskState = 'A');";
			prepStmt = (PreparedStatement)con.prepareStatement(sqlOuter);
			prepStmt.setInt(1, volunteerId);
			ResultSet rsOuter = prepStmt.executeQuery();
			prepStmt = null;
			while(rsOuter.next())
			{
				sqlInner = "select * from arogyaseva.event where eventId = ?";
				prepStmt = (PreparedStatement)con.prepareStatement(sqlInner);
				prepStmt.setInt(1, rsOuter.getInt("eventId"));
				ResultSet rsInner = prepStmt.executeQuery();
				prepStmt = null;
				while(rsInner.next())
				{
					eventDetails = new EventDetails();
					SchoolDetails schoolDetails = getSchoolDetails(rsInner.getInt("schoolId"));
					eventDetails.setSchool(schoolDetails.getSchoolName());
					eventDetails.setGpsCoordinates(schoolDetails.getCoordinates());
					eventDetails.setEventId(rsOuter.getInt("eventId"));
					eventDetails.setDate(rsInner.getString("eventDate"));
					eventDetails.setEventState(rsOuter.getString("taskState"));
					eventDetailsList.add(eventDetails);
				}
				
			}
			
			//prepStmt.close();
			con.close();
			
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return eventDetailsList;
	}
	
	public void removeEventOnReject(int volunteerId, int eventId)
	{
		try
		{
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		Connection con = null;
		String sql = null;
		PreparedStatement prepStmt = null;
		
		try
		{
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			sql = "update arogyaseva.eventmapping set taskState = 'R' where volunteerId = ? and eventId = ?;";
			prepStmt = (PreparedStatement)con.prepareStatement(sql);
			prepStmt.setInt(1, volunteerId);
			prepStmt.setInt(2, eventId);
			prepStmt.execute();
			
			prepStmt.close();
			con.close();
			
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	public SchoolDetails getSchoolDetails(int id)
	{
		SchoolDetails schoolDetails = new SchoolDetails();
		try
		{
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		Connection con = null;
		String sql = null;
		Statement stmt = null;
		
		try
		{
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select schoolname, locationCoordinates from arogyaseva.school where schoolId = " + id + ";");
			while(rs.next())
			{
				schoolDetails.setSchoolName(rs.getString("schoolname"));
				schoolDetails.setCoordinates(rs.getString("locationCoordinates"));
			}
			
			stmt.close();
			con.close();
			
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return schoolDetails;
	}
	
	private class SchoolDetails
	{
		private String schoolName;
		private String coordinates;
		public String getSchoolName()
		{
			return schoolName;
		}
		public void setSchoolName(String schoolName)
		{
			this.schoolName = schoolName;
		}
		public String getCoordinates()
		{
			return coordinates;
		}
		public void setCoordinates(String coordinates)
		{
			this.coordinates = coordinates;
		}
	}

	@Override
	public void updateEventOnAccept(int volunteerId, int eventId)
	{
		try
		{
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		Connection con = null;
		String sql = null;
		PreparedStatement prepStmt = null;
		
		try
		{
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			sql = "update arogyaseva.eventmapping set taskState = 'A' where volunteerId = ? and eventId = ?;";
			prepStmt = (PreparedStatement)con.prepareStatement(sql);
			prepStmt.setInt(1, volunteerId);
			prepStmt.setInt(2, eventId);
			prepStmt.execute();
			
			prepStmt.close();
			con.close();
			
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		
	}

}
