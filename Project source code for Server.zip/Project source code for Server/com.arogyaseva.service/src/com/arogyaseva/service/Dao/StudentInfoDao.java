package com.arogyaseva.service.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import com.arogyaseva.service.dto.StudentInfo;
import com.sun.jersey.core.util.Base64;

public class StudentInfoDao
{
	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost:3306/test";

	// Database credentials
	static final String USER = "root";
	static final String PASS = "jigar";
	
	public boolean saveStudentInfo(ArrayList<StudentInfo> studentInfoList)
	{
		//check if the record or student already exists, if it does add the medical readings to next time stamp number
		try
		{
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		try
		{
			Connection con = DriverManager.getConnection(DB_URL, USER, PASS);
			String sql1 = null;
			String sql2 = null;
			
			sql1 = "insert into arogyaseva.student(studentId, rollNo, name, age, schoolId) values (?, ?, ?, ?, ?);";
			sql2 = "insert into arogyaseva.medical_readings(readingId, studentId, timeStampNo, time_stamp, height, weight, chestNormal, chestExpand, photo, remarks) values (?,?,?,?,?,?,?,?,?,?);";
			
			
				
				
			
			
			
			for (StudentInfo studentInfo : studentInfoList)
			{
				StudentDeatils studentDetails = isFirstEntry(studentInfo);
				
				if(studentDetails.isFirstEntry())
				{
					int studentId = getStudentId();
					int schoolId = getSchoolId(studentInfo.getSchool());
					int readingId = getReadingId();
					Statement stmt1 = con.createStatement();
					Statement stmt2 = con.createStatement();
					System.out.println("Rahul"+studentInfo.getImage_str());
					stmt1.execute("insert into arogyaseva.student(studentId, rollNo, name, age, schoolId) values " +  "(" + studentId + "," + studentInfo.getRoll() + "," + "'" + studentInfo.getfName() + " " + studentInfo.getlName() + "'" + "," + studentInfo.getAge() + "," + schoolId + ");");
					stmt2.execute("insert into arogyaseva.medical_readings(readingId, studentId, timeStampNo, time_stamp, height, weight, chestNormal, chestExpand, photo, remarks) values " +  "(" + readingId + "," + studentId + ",1," + "'" + studentInfo.getDateTime() + "'" + "," + studentInfo.getHeight() + "," + studentInfo.getWeight() + "," + studentInfo.getcNormal() + "," + studentInfo.getcExpand() + "," + "'"+  studentInfo.getImage_str() + "'"+", null" + ");");
					stmt1.close();
					stmt2.close();
				}
				else	
				{
					int studentId = studentDetails.getStudentId();
					int readingId = getReadingId();
					int timeStampNo = getTimeStampNo(studentId);
					Statement stmt = con.createStatement();
					System.out.println("Rahul"+studentInfo.getImage_str());
					stmt.execute("insert into arogyaseva.medical_readings(readingId, studentId, timeStampNo, time_stamp, height, weight, chestNormal, chestExpand, photo, remarks) values " +  "(" + readingId + "," + studentId + ",1," + studentInfo.getDateTime() + "," + studentInfo.getHeight() + "," + studentInfo.getWeight() + "," + studentInfo.getcNormal() + "," + studentInfo.getcExpand() + "," +  "'"+  studentInfo.getImage_str() + "'"+",null" + ");");
					stmt.close();
				}	
			}
			return true;
		} catch (SQLException e)
		{
			e.printStackTrace();
			return false;
		}
		
	}
	
	private class StudentDeatils
	{
		private int studentId;
		private boolean firstEntry;
		
		public int getStudentId()
		{
			return studentId;
		}
		public void setStudentId(int studentId)
		{
			this.studentId = studentId;
		}
		public boolean isFirstEntry()
		{
			return firstEntry;
		}
		public void setFirstEntry(boolean firstEntry)
		{
			this.firstEntry = firstEntry;
		}
	}
	
	private StudentDeatils isFirstEntry(StudentInfo studentInfo)
	{
		StudentDeatils studentDeatils = new StudentDeatils();
		try
		{
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		
		Connection con = null;
		Statement stmt = null;
		
		studentDeatils.setFirstEntry(true);
		
		try
		{
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from arogyaseva.student where name ='"
					+ studentInfo.getfName() + " " + studentInfo.getlName() + "';");
			while(rs.next())
			{
				//studentDeatils.setFirstEntry(rs.getString("name").equals(null)?true : false);
				studentDeatils.setFirstEntry(false);
				studentDeatils.setStudentId(rs.getInt("studentId"));
			}
			
			stmt.close();
			con.close();
			
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return studentDeatils;
	}
	
	private int getStudentId()
	{
		try
		{
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		Connection con = null;
		Statement stmt = null;
		int maxId = 0;
		try
		{
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select max(studentId) from arogyaseva.student;");
			while(rs.next())
			{
				maxId = rs.getInt("max(studentId)");
			}
			
			stmt.close();
			con.close();
			
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return maxId + 1;
	}
	
	private int getSchoolId(String schoolName)
	{
		try
		{
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		Connection con = null;
		Statement stmt = null;
		int schoolId = 0;
		try
		{
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select schoolId from arogyaseva.school where schoolName=" + "'" + schoolName + "';");
			while(rs.next())
			{
				schoolId = rs.getInt("schoolId");
			}
			
			stmt.close();
			con.close();
			
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return schoolId;
	}
	
	private int getReadingId()
	{
		try
		{
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		Connection con = null;
		Statement stmt = null;
		int maxId = 0;
		try
		{
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select max(readingId) from arogyaseva.medical_readings;");
			while(rs.next())
			{
				maxId = rs.getInt("max(readingId)");
			}
			
			stmt.close();
			con.close();
			
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return maxId + 1;
	}
	
	private int getTimeStampNo(int studentId)
	{
		try
		{
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		Connection con = null;
		Statement stmt = null;
		int maxId = 0;
		try
		{
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select max(timeStampNo) from arogyaseva.medical_readings where studentId=" + studentId + ";");
			while(rs.next())
			{
				maxId = rs.getInt("timeStampNo");
			}
			
			stmt.close();
			con.close();
			
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return maxId + 1;
	}
	
	public ArrayList<StudentInfo> getStudentInfo(String schoolName)	//download
	{
		ArrayList<StudentInfo> studentInfoList = new ArrayList<StudentInfo>();
		
		try
		{
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		Connection con = null;
		Statement stmt = null;
		try
		{
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			int schoolId = getSchoolId(schoolName);
			ArrayList<StudentPersInfo> students = getStudents(schoolId);
			for (StudentPersInfo student : students)
			{
				StudentInfo studentInfo = new StudentInfo();
				int maxTimeStamp = getMaxTimeStamp(student.getStudentId());
				String[] fullName = student.getName().split(" ");
				studentInfo.setfName(fullName[0]);
				studentInfo.setlName(fullName[1]);
				studentInfo.setRoll(student.getRollNo());
				studentInfo.setAge(student.getAge());
				
				stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery("select * from arogyaseva.medical_readings where studentId=" + student.getStudentId() +  " and timeStampNo=" + maxTimeStamp + ";");
				while(rs.next())
				{
					studentInfo.setHeight(rs.getInt("height"));
					studentInfo.setWeight(rs.getInt("weight"));
					studentInfo.setcNormal(rs.getInt("chestNormal"));
					studentInfo.setcExpand(rs.getInt("chestExpand"));
					studentInfo.setSchool(schoolName);
					studentInfo.setDateTime(rs.getString("time_stamp"));
					studentInfo.setImage_str(rs.getString("photo"));
					System.out.println("From Download"+ rs.getString("photo"));
				}	
				studentInfoList.add(studentInfo);
			}
			
			stmt.close();
			con.close();
			
		}catch (SQLException e)
		{
			e.printStackTrace();
			return null;
		}
		
		return studentInfoList;
	}
	
	private int getMaxTimeStamp(int studentId)
	{
		try
		{
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		Connection con = null;
		Statement stmt = null;
		int maxId = 0;
		try
		{
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select max(timeStampNo) from arogyaseva.medical_readings where studentId=" + studentId + ";");
			while(rs.next())
			{
				maxId = rs.getInt("max(timeStampNo)");
			}
			
			stmt.close();
			con.close();
			
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return maxId;
	}
	
	private ArrayList<StudentPersInfo> getStudents(int schoolId)
	{
		ArrayList<StudentPersInfo> students = new ArrayList<StudentPersInfo>();
		try
		{
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		Connection con = null;
		Statement stmt = null;
		try
		{
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from arogyaseva.student where schoolId=" + schoolId + ";");
			while(rs.next())
			{
				StudentPersInfo studentPersInfo = new StudentPersInfo();
				studentPersInfo.setStudentId((rs.getInt("studentId")));
				studentPersInfo.setName(rs.getString("name"));
				studentPersInfo.setRollNo(rs.getInt("rollNo"));
				studentPersInfo.setAge(rs.getInt("age"));
				students.add(studentPersInfo);
			}
			
			stmt.close();
			con.close();
			
		} catch (SQLException e)
		{
			e.printStackTrace();
			return null;
		}
		
		return students;
	}
	
	private class StudentPersInfo
	{
		private int studentId;
		private String name;
		private int rollNo;
		private int age;
		public int getStudentId()
		{
			return studentId;
		}
		public void setStudentId(int studentId)
		{
			this.studentId = studentId;
		}
		public String getName()
		{
			return name;
		}
		public void setName(String name)
		{
			this.name = name;
		}
		public int getRollNo()
		{
			return rollNo;
		}
		public void setRollNo(int rollNo)
		{
			this.rollNo = rollNo;
		}
		public int getAge()
		{
			return age;
		}
		public void setAge(int age)
		{
			this.age = age;
		}
	}
}
