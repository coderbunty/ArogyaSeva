package com.arogyaseva.service.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.arogyaseva.service.dto.UserDetails;
//import com.mysql.jdbc.PreparedStatement;

public class LoginDao
{
	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost:3306/test";

	// Database credentials
	static final String USER = "root";
	static final String PASS = "jigar";

	public UserDetails getUserDetails(String uName, String pass)
	{
		UserDetails userDetails = new UserDetails();
		try
		{
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		Connection con = null;
		String sql = null;
		PreparedStatement prepStmt = null;
		
		try
		{
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			sql = "select * from arogyaseva.user where username=? and password=?;";
			prepStmt = (PreparedStatement)con.prepareStatement(sql);
			prepStmt.setString(1, uName);
			prepStmt.setString(2, pass);
			ResultSet rs = prepStmt.executeQuery();
			while(rs.next())
			{
				VolunteerDetails volunteerDetails = getVolunteerDetails(rs.getInt("userId"));
				userDetails.setUserName(uName);
				userDetails.setPassword(pass);
				userDetails.setUserId(volunteerDetails.getVolId());
				userDetails.setUserType(rs.getString("userType"));
			}
			
			prepStmt.close();
			con.close();
			
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		
		return userDetails;
	}
	
	private VolunteerDetails getVolunteerDetails(int userId)
	{
		VolunteerDetails volunteerDetails = new VolunteerDetails();
		try
		{
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		Connection con = null;
		String sql = null;
		Statement stmt = null;
		
		try
		{
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from arogyaseva.volunteer where userId = " + userId + ";");
			while(rs.next())
			{
				volunteerDetails.setVolId(rs.getInt("volunteerId"));
				volunteerDetails.setAddress(rs.getString("address"));
			}
			
			stmt.close();
			con.close();
			
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return volunteerDetails;
	}
	
	private class VolunteerDetails
	{
		private String address;
		private int volId;
		public String getAddress()
		{
			return address;
		}
		public void setAddress(String address)
		{
			this.address = address;
		}
		public int getVolId()
		{
			return volId;
		}
		public void setVolId(int volId)
		{
			this.volId = volId;
		}
	}
}
