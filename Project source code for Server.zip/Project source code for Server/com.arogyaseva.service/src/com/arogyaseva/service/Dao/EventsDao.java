package com.arogyaseva.service.Dao;

import java.util.ArrayList;

import com.arogyaseva.service.dto.EventDetails;

public interface EventsDao
{
	public ArrayList<EventDetails> getEventDetails(int volunteerId);
	public void removeEventOnReject(int volunteerId, int eventId);
	public void updateEventOnAccept(int volunteerId, int eventId);
}
