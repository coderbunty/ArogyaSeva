package com.arogyaseva.service.dto;

public class EventDetails
{
	private int eventId;
	private String volunteer;
	private String school;
	private String date;
	private String doctor;
	private String gpsCoordinates;
	private String eventState;
	
	public String getVolunteer()
	{
		return volunteer;
	}
	public void setVolunteer(String volunteer)
	{
		this.volunteer = volunteer;
	}
	public String getSchool()
	{
		return school;
	}
	public void setSchool(String school)
	{
		this.school = school;
	}
	public String getDate()
	{
		return date;
	}
	public void setDate(String date)
	{
		this.date = date;
	}
	public String getDoctor()
	{
		return doctor;
	}
	public void setDoctor(String doctor)
	{
		this.doctor = doctor;
	}
	public String getGpsCoordinates()
	{
		return gpsCoordinates;
	}
	public void setGpsCoordinates(String gpsCoordinates)
	{
		this.gpsCoordinates = gpsCoordinates;
	}
	public String getEventState()
	{
		return eventState;
	}
	public void setEventState(String eventState)
	{
		this.eventState = eventState;
	}
	public int getEventId()
	{
		return eventId;
	}
	public void setEventId(int eventId)
	{
		this.eventId = eventId;
	}
	
}
